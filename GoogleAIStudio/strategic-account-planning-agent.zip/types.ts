
export interface RoadmapItem {
  period: string;
  label: string;
  initiative: string;
  description: string;
  strategicValue: number; // 0-100 for charting
}

export interface SWOTData {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}

export interface Citation {
  title: string;
  uri: string;
}

export interface AccountAnalysis {
  ceoPriorities: string[];
  painPoints: string[];
  swot: SWOTData;
  roadmap: RoadmapItem[];
  marketContext: string;
  citations: Citation[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface AppState {
  isAnalyzing: boolean;
  error: string | null;
  results: AccountAnalysis | null;
  chatHistory: ChatMessage[];
  isChatting: boolean;
}
