
import { GoogleGenAI, Type, Chat } from "@google/genai";
import { AccountAnalysis } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export async function analyzeAccount(
  pdfBase64: string | null,
  goals: string
): Promise<AccountAnalysis> {
  // Use pro model for complex strategic reasoning and search tools
  const model = "gemini-3-pro-preview";
  
  const systemInstruction = `
    You are a Senior Strategic Account Management Agent. 
    Analyze the provided account data (annual report text or PDF) and goals.
    
    CRITICAL: Use your Google Search tool to find recent (last 30 days) news, stock trends, and competitor activities for this specific company to verify if the annual report data is still current.
    
    Context: The user has deep expertise in Engineering Services, Telecom, and AI/ML.
    
    Task:
    1. Identify 'CEO Priorities' and 'Pain Points'.
    2. Cross-reference these with Engineering Services, Telecom, and AI/ML.
    3. Generate a SWOT analysis.
    4. Generate a 3-year growth roadmap (Short: 0-6m, Mid: 6-18m, Long: 18+m).
    5. Provide a 'Market Context' summary based on real-time search results.
    
    Return output in strict JSON format.
  `;

  const prompt = `Strategic Goals: ${goals}. Analyze report and current market context.`;

  const contents: any = {
    parts: [{ text: prompt }]
  };

  if (pdfBase64) {
    contents.parts.push({
      inlineData: {
        mimeType: "application/pdf",
        data: pdfBase64
      }
    });
  }

  const response = await ai.models.generateContent({
    model,
    contents,
    config: {
      systemInstruction,
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          ceoPriorities: { type: Type.ARRAY, items: { type: Type.STRING } },
          painPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
          swot: {
            type: Type.OBJECT,
            properties: {
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
              opportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
              threats: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["strengths", "weaknesses", "opportunities", "threats"]
          },
          roadmap: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                period: { type: Type.STRING },
                label: { type: Type.STRING },
                initiative: { type: Type.STRING },
                description: { type: Type.STRING },
                strategicValue: { type: Type.NUMBER }
              },
              required: ["period", "label", "initiative", "description", "strategicValue"]
            }
          },
          marketContext: { type: Type.STRING, description: "Real-time market news summary" }
        },
        required: ["ceoPriorities", "painPoints", "swot", "roadmap", "marketContext"]
      }
    }
  });

  try {
    const text = response.text;
    const parsed = JSON.parse(text) as AccountAnalysis;
    
    // Extract grounding citations if available
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const citations = groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || 'External Source',
      uri: chunk.web?.uri || '#'
    })).filter((c: any) => c.uri !== '#') || [];

    return { ...parsed, citations };
  } catch (err) {
    console.error("Failed to parse AI response", err);
    throw new Error("Strategy synthesis failed. Please check inputs and try again.");
  }
}

let activeChatSession: Chat | null = null;

export function createStrategyChat(initialContext: string) {
  activeChatSession = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: `You are the Strategic Account Agent. You have just generated a roadmap for a client with the following context: ${initialContext}. Answer follow-up questions from the Business Development Leader to help them refine their pitch, draft emails, or evaluate risks.`
    }
  });
  return activeChatSession;
}

export async function sendChatMessage(message: string) {
  if (!activeChatSession) throw new Error("Chat session not initialized");
  const result = await activeChatSession.sendMessage({ message });
  return result.text;
}
