/** @jsx React.createElement */
/** @jsxFrag React.Fragment */
import React from 'react';
import { SWOTData } from '../types';

interface SWOTCardProps {
  data: SWOTData;
}

const SWOTCard: React.FC<SWOTCardProps> = ({ data }) => {
  const sections = [
    { title: 'Strengths', items: data.strengths, color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
    { title: 'Weaknesses', items: data.weaknesses, color: 'bg-amber-50 text-amber-700 border-amber-200' },
    { title: 'Opportunities', items: data.opportunities, color: 'bg-blue-50 text-blue-700 border-blue-200' },
    { title: 'Threats', items: data.threats, color: 'bg-rose-50 text-rose-700 border-rose-200' }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {sections.map((section) => (
        <div 
          key={section.title} 
          className={`p-4 rounded-xl border ${section.color} transition-all duration-300 hover:shadow-md`}
        >
          <h4 className="font-bold text-lg mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-current"></span>
            {section.title}
          </h4>
          <ul className="space-y-2 text-sm leading-relaxed">
            {section.items.map((item, idx) => (
              <li key={idx} className="flex gap-2">
                <span className="opacity-50">•</span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default SWOTCard;