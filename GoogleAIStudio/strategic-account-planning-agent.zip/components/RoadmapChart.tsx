/** @jsx React.createElement */
/** @jsxFrag React.Fragment */
import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  LabelList
} from 'recharts';
import { RoadmapItem } from '../types';

interface RoadmapChartProps {
  data: RoadmapItem[];
}

const RoadmapChart: React.FC<RoadmapChartProps> = ({ data }) => {
  const COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#ec4899'];

  return (
    <div className="w-full mt-6">
      <div className="h-[350px] w-full bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
        <h3 className="text-lg font-semibold mb-6 text-slate-800">Impact Comparison</h3>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis 
              dataKey="period" 
              axisLine={false} 
              tickLine={false}
              tick={{ fill: '#64748b', fontSize: 11 }}
            />
            <YAxis hide domain={[0, 110]} />
            <Tooltip 
              cursor={{ fill: '#f8fafc' }}
              contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            />
            <Bar dataKey="strategicValue" radius={[4, 4, 0, 0]} barSize={50}>
              {data.map((_, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
              <LabelList dataKey="label" position="top" fill="#475569" fontSize={10} offset={8} />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        {data.map((item, idx) => (
          <div key={idx} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-white transition-colors">
            <div className="flex justify-between items-start mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{item.period}</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-white border border-slate-100 text-slate-600 shadow-sm">{item.strategicValue}% Impact</span>
            </div>
            <h5 className="font-bold text-slate-800 text-sm mb-1">{item.initiative}</h5>
            <p className="text-[11px] text-slate-600 leading-relaxed">{item.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RoadmapChart;