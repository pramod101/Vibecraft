/** @jsx React.createElement */
/** @jsxFrag React.Fragment */
import React, { useState, useRef, useEffect } from 'react';
import { 
  FileText, 
  Target, 
  TrendingUp, 
  AlertCircle, 
  Loader2, 
  CheckCircle2, 
  ChevronRight,
  ShieldCheck,
  Activity,
  MessageSquare,
  Globe,
  ExternalLink,
  Send,
  Sparkles
} from 'lucide-react';
import { AppState, ChatMessage } from './types';
import { analyzeAccount, createStrategyChat, sendChatMessage } from './services/geminiService';
import SWOTCard from './components/SWOTCard';
import RoadmapChart from './components/RoadmapChart';

const App: React.FC = () => {
  const [goals, setGoals] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [base64File, setBase64File] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const [state, setState] = useState<AppState>({
    isAnalyzing: false,
    error: null,
    results: null,
    chatHistory: [],
    isChatting: false
  });

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.chatHistory]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type !== 'application/pdf') {
        alert('Please upload a PDF file.');
        return;
      }
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        if (typeof base64String === 'string') {
          setBase64File(base64String.split(',')[1]);
        }
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleGenerate = async () => {
    if (!goals.trim()) {
      setState(prev => ({ ...prev, error: 'Please specify account goals first.' }));
      return;
    }
    setState({ ...state, isAnalyzing: true, error: null, results: null });
    try {
      const results = await analyzeAccount(base64File, goals);
      createStrategyChat(`Strategic Goals: ${goals}. CEO Priorities: ${results.ceoPriorities.join(', ')}`);
      setState({ ...state, isAnalyzing: false, error: null, results });
    } catch (err: any) {
      setState({ ...state, isAnalyzing: false, error: err.message, results: null });
    }
  };

  const handleSendChat = async () => {
    if (!chatInput.trim() || state.isChatting) return;
    const userMsg: ChatMessage = { role: 'user', text: chatInput };
    setState(prev => ({ 
      ...prev, 
      chatHistory: [...prev.chatHistory, userMsg],
      isChatting: true 
    }));
    setChatInput('');

    try {
      const reply = await sendChatMessage(chatInput);
      const modelMsg: ChatMessage = { role: 'model', text: reply };
      setState(prev => ({ 
        ...prev, 
        chatHistory: [...prev.chatHistory, modelMsg],
        isChatting: false 
      }));
    } catch (err) {
      setState(prev => ({ ...prev, isChatting: false }));
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg">
              <TrendingUp size={20} />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-700 to-indigo-500">
              Account Strategy Agent
            </h1>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm text-slate-500 font-medium">
            <span className="flex items-center gap-1.5"><Globe size={16} className="text-blue-500" /> Real-time Grounding</span>
            <span className="flex items-center gap-1.5"><ShieldCheck size={16} className="text-emerald-500" /> Executive Grade</span>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Inputs & Chat */}
        <div className="lg:col-span-4 space-y-6 flex flex-col h-full">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <h2 className="text-lg font-bold flex items-center gap-2 text-slate-800">
              <Target size={20} className="text-indigo-600" />
              Strategic Configuration
            </h2>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Client Annual Report (PDF)</label>
              <div className="relative group">
                <input type="file" accept=".pdf" onChange={handleFileChange} className="hidden" id="file-upload" />
                <label htmlFor="file-upload" className={`flex flex-col items-center justify-center w-full h-24 border-2 border-dashed rounded-xl cursor-pointer transition-all ${file ? 'bg-indigo-50 border-indigo-300' : 'border-slate-200 hover:border-indigo-400 hover:bg-slate-50'}`}>
                  <FileText className={`mb-1 ${file ? 'text-indigo-600' : 'text-slate-400'}`} size={20} />
                  <span className="text-[11px] text-center px-4 font-medium text-slate-600">{file ? file.name : 'Upload PDF Report'}</span>
                </label>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Account Goals</label>
              <textarea value={goals} onChange={(e) => setGoals(e.target.value)} placeholder="Define targets & expertise..." className="w-full h-28 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none transition-all resize-none" />
            </div>

            <button onClick={handleGenerate} disabled={state.isAnalyzing} className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-md transition-all">
              {state.isAnalyzing ? <Loader2 className="animate-spin" size={20} /> : <><Sparkles size={18} /> Generate Strategy</>}
            </button>
          </div>

          {/* Chat Advisor */}
          {state.results && (
            <div className="flex-1 min-h-[400px] flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <h3 className="text-sm font-bold flex items-center gap-2 text-slate-800">
                  <MessageSquare size={16} className="text-indigo-600" />
                  Strategy Advisor
                </h3>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {state.chatHistory.length === 0 && (
                  <p className="text-xs text-slate-400 text-center py-8">Ask follow-up questions about the roadmap or draft outreach emails.</p>
                )}
                {state.chatHistory.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed ${msg.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-800'}`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                {state.isChatting && (
                  <div className="flex justify-start">
                    <div className="bg-slate-100 p-3 rounded-2xl flex gap-1">
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>
              <div className="p-3 bg-white border-t border-slate-100 flex gap-2">
                <input 
                  value={chatInput} 
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendChat()}
                  placeholder="Ask for advice..." 
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <button onClick={handleSendChat} className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                  <Send size={14} />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-8 space-y-8">
          {state.isAnalyzing ? (
            <div className="h-full min-h-[600px] flex flex-col items-center justify-center text-center space-y-6 bg-white rounded-2xl border border-slate-100">
              <div className="relative">
                <Loader2 className="animate-spin text-indigo-600" size={56} />
                <Globe className="absolute inset-0 m-auto text-indigo-300 animate-pulse" size={24} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-slate-800">Grounding Strategy in Real-Time</h3>
                <p className="text-slate-500 max-w-xs mx-auto text-sm leading-relaxed">
                  We're cross-referencing the annual report with live market news and stock trends...
                </p>
              </div>
            </div>
          ) : state.results ? (
            <div className="space-y-8">
              {/* Market Intelligence Alert */}
              <div className="bg-blue-600 text-white p-6 rounded-2xl shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <Globe size={120} />
                </div>
                <div className="relative z-10 space-y-3">
                  <div className="flex items-center gap-2">
                    <Activity size={18} className="text-blue-200" />
                    <h3 className="text-sm font-bold uppercase tracking-widest text-blue-100">Market Pulse Intelligence</h3>
                  </div>
                  <p className="text-sm leading-relaxed text-blue-50 font-medium">
                    {state.results.marketContext}
                  </p>
                  {state.results.citations.length > 0 && (
                    <div className="pt-2 flex flex-wrap gap-2">
                      {state.results.citations.slice(0, 3).map((cite, i) => (
                        <a key={i} href={cite.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-[10px] bg-blue-500/50 hover:bg-blue-400 py-1 px-2 rounded border border-blue-400 transition-colors">
                          <ExternalLink size={10} />
                          {cite.title}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                  <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-widest mb-4">CEO Top Priorities</h3>
                  <div className="space-y-3">
                    {state.results.ceoPriorities.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 text-sm text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-100">
                        <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                  <h3 className="text-sm font-bold text-rose-600 uppercase tracking-widest mb-4">Key Pain Points</h3>
                  <div className="space-y-3">
                    {state.results.painPoints.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 text-sm text-slate-700 bg-rose-50/30 p-3 rounded-lg border border-rose-100">
                        <AlertCircle size={16} className="text-rose-500 shrink-0" />
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Strategic SWOT Analysis</h3>
                <SWOTCard data={state.results.swot} />
              </div>

              <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-2">3-Year Growth Roadmap</h3>
                <RoadmapChart data={state.results.roadmap} />
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 bg-slate-50/50 rounded-2xl border-2 border-dashed border-slate-200">
              <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mb-6">
                <Target size={40} />
              </div>
              <h3 className="text-2xl font-bold text-slate-800">Strategy Workspace</h3>
              <p className="text-slate-500 max-w-sm mx-auto mt-3 text-sm leading-relaxed">
                Upload your client report to unlock real-time market insights and a structured 3-year growth roadmap.
              </p>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-[10px] text-slate-400 uppercase tracking-widest font-bold">
          Account Strategy Intelligence Platform • Powered by Gemini Pro & Google Search
        </div>
      </footer>
    </div>
  );
};

export default App;